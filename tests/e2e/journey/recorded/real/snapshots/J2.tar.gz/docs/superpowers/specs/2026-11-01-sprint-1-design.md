# Sprint 1 design: Library desk

Status: written at chart, 2026-11-01. Source: `.rig/product/sprints/sprint-1/prd.md` (in rig format, no conversion needed) and `requirements.md` (ledger). Superpowers is disabled in this repo, so this design was written by the chart's own rules, in one pass, without a brainstorm dialogue.

## Context

A single Python library, standard library only at runtime. It keeps the catalogue and the loans in one JSON file and checks the desk's lending rules on borrow and return. Dates are `datetime.date`. One process at a time, no locking.

## Design

Decisions marked `(decided at chart)` are the chart's recommendation, taken because the PRD leaves the choice open. The questions OQ-1, GQ-1, GQ-2 and GQ-3 are answered in `prd.md` under `## Decisions`; they are listed below under "Decisions from the PRD". No question is open.

### Modules (`src/library/`)

- `errors.py`: the exception classes the ACs name: `ValidationError`, `DuplicateIsbnError`, `BookNotFoundError`, `LoanLimitError`, `NoCopyAvailableError`, `OverdueLoanError`, `LoanNotFoundError`, `StorageError`. (decided at chart)
- `storage.py`: reads the data file and writes it. A missing file gives an empty library (AC-1.1). Invalid JSON raises `StorageError` naming the file and leaves the file byte-for-byte unchanged (AC-1.4). Writes go to a temp file in the same directory, then `os.replace` onto the data file, so a half-written file never appears (NFR-1).
- `library.py`: `class Library`. The constructor takes the data file path and loads it. (decided at chart: `Library(path)` loads on construction; the PRD says "when the library is loaded" and names no other entry point.) Public methods: `add_book`, `find_book`, `check_out`, `return_book`, `available`. Each one checks every rule first, changes in-memory state only after all checks pass, writes the file before a successful `add_book`, `check_out` or `return_book` returns, and never writes it when a call raises (AC-1.3). (decided at chart: there is no `save()` call.) Failed calls leave both memory and file unchanged.
- `lending.py`: the two limits as the only literals in the package: `LOAN_LIMIT = 3` (DR-4) and `LOAN_DAYS = 14` (DR-5). Due date is `checked_out + timedelta(days=LOAN_DAYS)`. Nothing else repeats these numbers (NFR-2).

### Check order for `check_out` (from the PRD Decision, dated 2026-10-31)

1. unknown isbn: `BookNotFoundError`
2. overdue loan held by the member: `OverdueLoanError` (a loan is overdue when its due date is before the `check_out` day; a loan due that day is not overdue)
3. loan limit reached: `LoanLimitError`
4. no free copy: `NoCopyAvailableError`

### Identity and matching

- isbn: non-empty string, exact and case-sensitive match (DR-1, AC-3.4).
- Duplicate isbn rejected at add (AC-2.4).
- A member is a plain id string on a loan. No member registry (non-goal).
- A member may hold several loans of the same isbn; each counts toward the limit (Decision).

### Decisions from the PRD

- Overdue (AC-4.5, DR-6), answered by the person: a loan is overdue when its due date is before the `check_out` day; a loan due that day is not overdue. Checked at `check_out` only: no background job, no stored flag. Lending intent.
- `return_book(member, isbn, day)`: the day is a required third argument; AC-5.1's two-argument call is shorthand. (decided at chart) Lending intent.
- Writes: a successful `add_book`, `check_out` or `return_book` writes the data file before it returns; no `save()` call; a call that raises writes nothing. (decided at chart) Catalogue and lending intents.
- Scale: no target this sprint. (decided at chart)
- Unreadable data file (`OSError` on open): raised as the `OSError`, not wrapped in `StorageError`. (decided at chart) Data-file intent.
- Two loans of one isbn returned once: the loan checked out earliest is removed. (decided at chart) Lending intent.

## Intents

- walking-skeleton: package modules and the eight error classes, importable from `library`; `tests/test_smoke.py` stays green (FR-2, FR-3, FR-4, FR-5 raise these errors)
- data-file: `Library(path)` loads or starts empty, invalid JSON raises StorageError and leaves the file unchanged, atomic write (FR-1, NFR-1)
- catalogue: add_book and find_book with validation, duplicate check and exact isbn matching (FR-2, FR-3, DR-1, DR-3)
- lending: check_out and return_book with the four-step check order, the loan limit, the loan period and the copy count (FR-4, FR-5, DR-2, DR-4, DR-5, DR-6, DR-7, NFR-2)
