---
sprint: 1
prd: [FR-1, FR-2, FR-3, FR-4, FR-5]
depends: []
estimate_days: 1
kind: internal
owner:
status: draft
scope: [src/library/__init__.py, src/library/errors.py, src/library/storage.py, src/library/library.py, src/library/lending.py, tests/test_errors.py]
touches: []
---
# Walking skeleton: package modules and the eight error classes

## Intent

The package is empty today. Every later intent raises the errors the acceptance criteria name and adds code to one of four modules. This intent creates the four modules and the eight error classes, importable from `library`, so the next intents add behaviour without moving files. Done: `from library import ValidationError, DuplicateIsbnError, BookNotFoundError, LoanLimitError, NoCopyAvailableError, OverdueLoanError, LoanNotFoundError, StorageError, Library` works, `tests/test_smoke.py` stays green, and no module has behaviour yet.

## Non-goals

- Do not add behaviour to `Library`, `storage` or `lending`: the module files hold a docstring and, for `Library`, an empty class.
- Do not add a ninth error class or a common base class: the design lists eight.
- Do not edit `tests/test_smoke.py`.

## Design

| Part | Responsibility | Must not |
|---|---|---|
| `errors.py` | the eight exception classes, each a direct subclass of `Exception` | import any other module of the package |
| `storage.py` | placeholder for reading and writing the data file (built in data-file) | import `library` or `lending` |
| `library.py` | placeholder `class Library` (built in data-file, catalogue, lending) | be imported by `errors`, `storage` or `lending` |
| `lending.py` | placeholder for `LOAN_LIMIT`, `LOAN_DAYS` (built in lending) | import `library` or `storage` |
| `__init__.py` | re-exports `Library` and the eight error classes | hold logic |

## Interfaces

none (internal)

## Behaviours

- B1 (FR-2, AC-2.2, AC-2.3, AC-2.4): `ValidationError` and `DuplicateIsbnError` can be imported from `library`; raised with a message, `str(error)` is that message.
- B2 (FR-3, AC-3.2): `BookNotFoundError` can be imported from `library`; `str(error)` is the message it was raised with.
- B3 (FR-4, AC-4.2, AC-4.3, AC-4.5): `LoanLimitError`, `NoCopyAvailableError` and `OverdueLoanError` can be imported from `library`.
- B4 (FR-5, AC-5.2): `LoanNotFoundError` can be imported from `library`; raised with "Book 978-1 is not on loan to member m1", `str(error)` is exactly that text.
- B5 (FR-1, AC-1.4): `StorageError` can be imported from `library`; `str(error)` is the message it was raised with.

### Failure behaviour

none

## Tests required

- B1 to B5: unit, `tests/test_errors.py` (one import test per class, plus the message round trip of B4).
- `tests/test_smoke.py` stays green (existing file, not edited).

## Open questions

none
