verdict: pass

## Review 2 (after the person's answers and the minimal decisions)

## Findings
1. [medium] implementation-plan.md:86-89 and :103-110 (catalogue B10 before B11; lending B14 before B16): the no-write tests (spy on `storage.save` never called, plus unchanged bytes) are scheduled before the task that makes a successful call write the file. Until B11 or B16 adds the `storage.save` call, those spy tests pass without a code change, so the red-proof step cannot hold. The return_book no-write test (TC-46) has no failing-test task of its own → put the write-on-success tasks (B11, B16) before the B10 and B14 no-write tasks, or add a no-write re-run task after them (confidence 80) → fixed (confirmed)
2. [medium] testplan/cases.md:49 (TC-49, intent data-file B2): the case calls `add_book`, but data-file.md:22 forbids `add_book` in that intent and the method is built a lane step later. It also duplicates TC-51 (catalogue B11), and the case itself says "see TC-51" → delete TC-49 and keep TC-51 (confidence 85) → fixed (confirmed)
3. [medium] prd.md:126 (Decision "the day is a required argument of check_out and return_book; there is no default of today") and testplan/cases.md: every case passes a day, so a default of `date.today()` would still pass all of them. No case calls `check_out` or `return_book` without a day and expects `TypeError` → add one case for each method (confidence 80) → fixed (confirmed)
4. [medium] testplan/cases.md:55 (TC-55) vs prd.md:133 and adr/0002:31: the case checks out on 03-01, then 03-02, so "earliest checked out" and "first in the file" are the same loan. `day` is free, so the order of calls and the order of dates can differ → check out on 03-02 first, then 03-01, and assert the 03-01 loan is the one removed (confidence 80) → fixed (confirmed)
5. [low] intents/lending.md:16: "Done: AC-4.1 to AC-4.4 and AC-5.1 to AC-5.3" leaves out AC-4.5, which B15 and TC-47, TC-50 and TC-52 cover → add AC-4.5 (confidence 85) → fixed (confirmed)

## Deferred
- prd.md:135: `## Open questions` is empty. The decisions at prd.md:129-133 say "Answers GQ-1/2/3", but those ids are defined only in the removed open-question list. Descriptive only.
- The five "decided at chart, minimal option" decisions are the chart's choices, not the person's answers. The approver should confirm them.
- cases.md:33,40 (TC-33, TC-40): the data for "m1 holds 2 or 3 loans" is unspecified. Name the books, as TC-34 does.
- cases.md:56 (TC-56): "writes nothing" names no check. Add a spy on `storage.save` and an empty temp-file listing.
- cases.md:39 (TC-39): the scan does not forbid a second literal 3 or 14 inside lending.py (confidence 65).
- architecture.md:112: steps 8 and 9 of the text flow are fused on one line.
- Carried from the first review: ADR 0001:27 (stray temp file after a crash) against the NFR-1 target of 0 half-written files; `copies=True` and the unseeded sequences in TC-37; design.md does not mention `Book` or `Loan`.
