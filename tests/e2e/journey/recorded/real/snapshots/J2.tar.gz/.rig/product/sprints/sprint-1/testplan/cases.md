# Test cases (.rig/product/sprints/sprint-1/testplan/cases.md)

| ID | Requirement | Intent | Behaviour | Level | Data | Expected | Access |
|---|---|---|---|---|---|---|---|
| TC-1 | FR-2, AC-2.2, AC-2.3, AC-2.4 | walking-skeleton | B1 | unit | - | ValidationError and DuplicateIsbnError import from `library`; raised with "x", str(error) is "x" | - |
| TC-2 | FR-3, AC-3.2 | walking-skeleton | B2 | unit | - | BookNotFoundError imports from `library`; message round trip is exact | - |
| TC-3 | FR-4, AC-4.2, AC-4.3, AC-4.5 | walking-skeleton | B3 | unit | - | LoanLimitError, NoCopyAvailableError and OverdueLoanError import from `library` | - |
| TC-4 | FR-5, AC-5.2 | walking-skeleton | B4 | unit | - | LoanNotFoundError raised with "Book 978-1 is not on loan to member m1" has exactly that str | - |
| TC-5 | FR-1, AC-1.4 | walking-skeleton | B5 | unit | - | StorageError imports from `library`; message round trip is exact | - |
| TC-6 | FR-1, AC-1.1 | data-file | B1 | unit | - | Library(tmp_path/"lib.json") with no file has no books and no loans, and the file is not created | - |
| TC-7 | FR-1, AC-1.2 | data-file | B2 | unit | data/valid.json | Library on a copy holds Book("978-1", "Dune", 2) and the loan for m1 checked out date(2026, 3, 1) due date(2026, 3, 15); same result after storage.save then Library(path) | - |
| TC-8 | FR-1, DR-2 | data-file | B2 | unit | data/valid.json | The loan holds member, isbn, checked_out and due; both dates are datetime.date, not strings | - |
| TC-9 | NFR-1 | data-file | B3 | unit | - | storage.save writes a temp file in the data file's directory, then os.replace onto the data file (os.replace spy sees a temp path in the same directory); no temp file remains | - |
| TC-10 | FR-1, NFR-1 | data-file | B4 | unit | data/valid.json | With json.dump forced to raise, storage.save raises, the data file keeps its previous bytes, no temp file remains | - |
| TC-11 | FR-1, NFR-1 | data-file | B4 | unit | data/valid.json | With os.replace forced to raise, storage.save raises, the data file keeps its previous bytes, the temp file is removed | - |
| TC-14 | FR-1, AC-1.4 | data-file | B5 | unit | data/invalid.json | Library(path) raises StorageError whose message contains the file path; the file bytes are identical before and after | - |
| TC-17 | FR-1, AC-1.3 | data-file | B6 | unit | data/invalid.json | After the raising Library(path), the directory holds only the original file: nothing written, no temp file; storage.save spy never called | - |
| TC-18 | FR-2, AC-2.1 | catalogue | B1 | unit | - | On an empty library add_book("978-1", "Dune", 2) leaves Library.books holding Book("978-1", "Dune", 2) | - |
| TC-19 | FR-3, AC-3.1 | catalogue | B2 | unit | - | find_book("978-1") returns the book with title "Dune" and 2 copies | - |
| TC-20 | FR-3, AC-3.3 | catalogue | B3 | unit | - | find_book("999", raise_missing=False) returns None | - |
| TC-21 | FR-3, AC-3.4, DR-1 | catalogue | B4 | unit | - | With isbn "ABC-1" added, find_book("abc-1") raises BookNotFoundError | - |
| TC-22 | FR-2, DR-1, DR-3 | catalogue | B5 | unit | - | add_book("978-1", "Dune", 1) is accepted (boundary of copies 1 or more) | - |
| TC-23 | FR-2, AC-2.2, DR-1 | catalogue | B6 | unit | - | add_book("", "Dune", 2) raises ValidationError; books unchanged | - |
| TC-24 | FR-2, AC-2.2 | catalogue | B6 | unit | - | add_book("978-1", "", 2) raises ValidationError; books unchanged | - |
| TC-25 | FR-2, AC-2.2, DR-1 | catalogue | B6 | unit | - | add_book(978, "Dune", 2) (isbn not a string) raises ValidationError; books unchanged | - |
| TC-26 | FR-2, AC-2.3, DR-3 | catalogue | B7 | unit | - | add_book with copies 0 and with -1 raises ValidationError; books unchanged | - |
| TC-27 | FR-2, AC-2.3, DR-3 | catalogue | B7 | unit | - | add_book with copies "2" and with 1.5 raises ValidationError; books unchanged | - |
| TC-28 | FR-2, AC-2.4, DR-1 | catalogue | B8 | unit | - | A second add_book("978-1", "Other", 5) raises DuplicateIsbnError; the first book keeps title "Dune" and 2 copies | - |
| TC-29 | FR-3, AC-3.2 | catalogue | B9 | unit | - | find_book("999") on an unknown isbn raises BookNotFoundError | - |
| TC-30 | FR-1, AC-1.3 | catalogue | B10 | unit | - | After each failing add_book of TC-23, TC-26 and TC-28, the file bytes (or its absence) are identical to before and the storage.save spy is never called | - |
| TC-31 | FR-4, AC-4.1, DR-2 | lending | B1 | unit | - | check_out("m1", "978-1", date(2026, 3, 1)) on a 2-copy book records Loan(m1, 978-1, 2026-03-01, due 2026-03-15); available("978-1") goes from 2 to 1 | - |
| TC-32 | FR-4, AC-4.1, DR-5 | lending | B2 | unit | - | check_out on date(2026, 2, 20) records due date 2026-03-06 | - |
| TC-33 | FR-4, DR-4 | lending | B3 | unit | - | m1 holds 2 loans; the third check_out succeeds and m1 holds 3 | - |
| TC-34 | FR-4, DR-4 | lending | B4 | unit | - | 3-copy book "978-1": m1 checks it out twice, then a second book "978-2" once; m1 holds 3 loans including the duplicate isbn, and a fourth check_out by m1 raises LoanLimitError | - |
| TC-35 | FR-4, DR-7 | lending | B5 | unit | - | 2 copies, 1 loan: the next check_out by m2 succeeds; with 2 loans the next is refused (see TC-41) | - |
| TC-36 | FR-5, AC-5.1 | lending | B6 | unit | - | m1 holds a loan of "978-1"; return_book("m1", "978-1", date(2026, 3, 5)) removes the loan and available goes up by one (from 1 to 2 on a 2-copy book) | - |
| TC-37 | FR-5, AC-5.3, DR-7 | lending | B7 | unit | - | 2 copies; random sequences of check_out(member, isbn, day) and return_book(member, isbn, day) by m1 and m2 (accepted or refused) keep available("978-1") between 0 and 2 after every call | - |
| TC-38 | FR-5, AC-5.3, DR-7 | lending | B7 | unit | - | 2 copies; sequences of check_out calls by m1 and m2 only (accepted or refused, no return) keep available("978-1") between 0 and 2 after every call; a refused third check_out leaves it at 0 | - |
| TC-39 | NFR-2, DR-4, DR-5 | lending | B8 | unit | - | AST scan (`ast.parse`) of every file in `src/library/`: LOAN_LIMIT = 3 and LOAN_DAYS = 14 are each assigned once, in lending.py; no integer constant 3 or 14 appears in any other file | - |
| TC-40 | FR-4, AC-4.2, DR-4 | lending | B9 | unit | - | m1 holds 3 loans; the fourth check_out raises LoanLimitError; loans unchanged | - |
| TC-41 | FR-4, AC-4.3, DR-7 | lending | B10 | unit | - | 2-copy book with 2 loans (m1, m2); check_out by a third member "m3" raises NoCopyAvailableError; loans unchanged | - |
| TC-42 | FR-4, AC-4.4 | lending | B11 | unit | - | check_out("m1", "999", date(2026, 3, 1)) raises BookNotFoundError; loans unchanged | - |
| TC-43 | FR-4, AC-4.2, AC-4.3, AC-4.4 | lending | B12 | unit | - | Unknown isbn raises BookNotFoundError even when m1 is at the loan limit; the loan limit raises LoanLimitError before no free copy raises NoCopyAvailableError | - |
| TC-44 | FR-5, AC-5.2 | lending | B13 | unit | - | return_book("m1", "978-1", date(2026, 3, 5)) when m1 does not hold it raises LoanNotFoundError with exactly "Book 978-1 is not on loan to member m1"; loans unchanged | - |
| TC-45 | FR-1, AC-1.3 | lending | B14 | unit | - | After each failing check_out of TC-40, TC-41 and TC-42, the file bytes (or its absence) are identical to before and the storage.save spy is never called | - |
| TC-46 | FR-1, AC-1.3 | lending | B14 | unit | - | After the failing return_book of TC-44 the file bytes are identical to before and the storage.save spy is never called | - |
| TC-47 | FR-4, AC-4.5, DR-6 | lending | B15 | unit | - | m1 holds a loan due 2026-03-15; check_out("m1", "978-2", date(2026, 3, 20)) raises OverdueLoanError; loans unchanged | - |
| TC-48 | FR-4, AC-4.5, DR-6 | lending | B12 | unit | - | Order of rules: unknown isbn raises BookNotFoundError before OverdueLoanError; with m1 overdue and at the loan limit, OverdueLoanError is raised before LoanLimitError | - |
| TC-50 | FR-4, AC-4.5, DR-6 | lending | B15 | unit | - | Boundary, overdue side: m1 holds a loan due 2026-03-15 (checked out 2026-03-01); check_out("m1", "978-2", date(2026, 3, 16)) raises OverdueLoanError; loans unchanged | - |
| TC-51 | FR-1, AC-1.2 | catalogue | B11 | unit | - | A successful add_book writes the file before it returns: a new Library(path) on the same file holds the added book | - |
| TC-52 | FR-4, AC-4.5, DR-6 | lending | B15 | unit | - | Boundary, not-overdue side: m1 holds a loan due 2026-03-15 (checked out 2026-03-01); check_out("m1", "978-2", date(2026, 3, 15)) is accepted and m1 holds 2 loans | - |
| TC-53 | FR-1, FR-4, AC-1.2 | lending | B16 | unit | - | A successful check_out writes the file before it returns: a new Library(path) on the same file holds the loan | - |
| TC-54 | FR-1, FR-5, AC-1.2 | lending | B16 | unit | - | A successful return_book writes the file before it returns: a new Library(path) on the same file no longer holds the loan | - |
| TC-55 | FR-5, AC-5.1, DR-2 | lending | B6 | unit | - | 3-copy book; m1 checks out "978-1" first on date(2026, 3, 2) and then on date(2026, 3, 1), then return_book("m1", "978-1", date(2026, 3, 3)) once: the loan checked out 2026-03-01 (the later-recorded, earlier-dated one) is the one removed and the 2026-03-02 loan remains | - |
| TC-56 | FR-1, AC-1.3 | data-file | B7 | unit | - | The data file exists but cannot be read (`open` forced to raise PermissionError with monkeypatch, or a directory as the path): Library(path) raises the OSError as it is, not StorageError, and writes nothing (PRD Decision: unreadable data file is raised as the OSError) | - |
| TC-57 | FR-4 | lending | B1 | unit | - | check_out("m1", "978-1") called without the day raises TypeError (prd.md line 126 Decision: the day is a required argument, no default of today); loans unchanged | - |
| TC-58 | FR-5 | lending | B6 | unit | - | return_book("m1", "978-1") called without the day raises TypeError (prd.md line 126 Decision: the day is a required argument, no default of today); loans unchanged | - |
