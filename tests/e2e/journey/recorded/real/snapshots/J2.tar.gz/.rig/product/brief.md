# Product brief

## Context and intent

A small library desk keeps books and loans on paper, so staff lose track of who holds which book and how many copies are free. Sprint 1 delivers a Python library (`src/library/`) that keeps the catalogue and the loans in one JSON file and checks the desk's lending rules when a book is borrowed or returned. Success: the acceptance criteria of FR-1 to FR-5 pass under `pytest`.

## Non-goals

- Do not add fines, reservations, renewals or reports.
- Do not add a member registry: a member is an id string on a loan.
- Do not add a command line, web UI or GUI.
- Do not add editing or removing a book.
- Do not add locking or file permission handling (single user, one process at a time).

## Architecture

See `.rig/product/architecture.md` (design: `docs/superpowers/specs/2026-11-01-sprint-1-design.md`).

## Constraints

- Python 3.11+, standard library only at runtime, pytest for tests; source in `src/library/`, tests in `tests/`; dates are `datetime.date`.
- Ask first: adding a runtime dependency or changing the data file format. Never write the data file when an operation fails.
- NFR-1: writes are atomic (temp file, then rename): 0 half-written files after a failed or interrupted write.
- NFR-2: the loan limit and the loan period are each defined in exactly one place: 1 definition each, 0 repeated literals.

## Interfaces

The `library` package API: `Library(path)`, `add_book`, `find_book`, `check_out`, `return_book`, `available`, and the eight error classes. No HTTP, message or downstream interface, so no contract files.

## Behaviours

see the intents

### Failure behaviour

see the intents

## Tests required

see the intents

## Open questions

none
