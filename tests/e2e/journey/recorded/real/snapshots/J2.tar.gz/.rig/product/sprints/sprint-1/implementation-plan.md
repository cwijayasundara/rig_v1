---
sprint: 1
updated: 2026-11-01
---
# Sprint 1 implementation plan

**Goal:** A small Python library that keeps the catalogue and the loans in one JSON file and checks the desk's lending rules on borrow and return.

**Architecture:** Four modules under `src/library/`: `errors.py` (eight exceptions), `storage.py` (load and atomic save), `lending.py` (the two limits), `library.py` (`Library`, which uses the other three). Dependencies point inward to `errors`; see `.rig/product/architecture.md`.

**Tech stack:** Python 3.11+, standard library only at runtime (`json`, `datetime`, `os`, `tempfile`), pytest, ruff, mypy.

**Design:** docs/superpowers/specs/2026-11-01-sprint-1-design.md

## Global constraints

- Standard library only at runtime; adding a dependency or changing the data file format (ADR 0002) needs a person first.
- Every rule is checked before any state changes; a call that raises leaves memory and file unchanged (AC-1.3).
- Dates are `datetime.date`; the file holds ISO strings (ADR 0002).
- `LOAN_LIMIT` and `LOAN_DAYS` are defined once, in `lending.py` (NFR-2).
- Writes go through `storage.save` only (ADR 0001, NFR-1).
- Fix code, never tests; `ruff check src tests`, `mypy` and `pytest -q` pass before each commit.

## Review focus

- No `os.replace` or `open(..., "w")` outside `storage.save`.
- State changes only after every check passes in `add_book`, `check_out` and `return_book`.
- The check order in `check_out`: unknown isbn, overdue (due date before the `check_out` day; due that day is not overdue), loan limit, no free copy.
- Every successful `add_book`, `check_out` and `return_book` writes the file before it returns; a raising call never calls `storage.save`.
- No literal 3 or 14 for the limit or the period outside `lending.py`.

## Allocation

| Lane | Intents | Days | Suits | Why |
|---|---|---|---|---|
| 1 | walking-skeleton → data-file → catalogue → lending | 6 | senior | one engineer; storage and the atomic write are the base every later intent builds on |

## Intents

### walking-skeleton

Depends on: none · Estimate: 1 · Suits: any

Files: src/library/__init__.py, errors.py, storage.py, library.py, lending.py; tests: tests/test_errors.py.

Interfaces: the eight classes in `errors.py` (direct subclasses of `Exception`); empty `class Library`; `__init__.py` re-exports `Library` and the eight classes.

- [ ] B1: write the failing import and message test for `ValidationError` and `DuplicateIsbnError` in tests/test_errors.py; run it and see it fail
- [ ] B2: write the failing import and message test for `BookNotFoundError` in tests/test_errors.py; run it and see it fail
- [ ] B3: write the failing import test for `LoanLimitError`, `NoCopyAvailableError` and `OverdueLoanError` in tests/test_errors.py; run it and see it fail
- [ ] B4: write the failing test that `LoanNotFoundError("Book 978-1 is not on loan to member m1")` has that exact `str` in tests/test_errors.py; run it and see it fail
- [ ] B5: write the failing import and message test for `StorageError` in tests/test_errors.py; run it and see it fail
- [ ] B1 to B5: create errors.py with the eight classes, placeholder modules storage.py, library.py (empty `Library`), lending.py, and the re-exports in `__init__.py`; the tests pass
- [ ] run `pytest -q`, `ruff check src tests`, `mypy --exclude '^\.(rig|claude)/' .`; tests/test_smoke.py stays green

### data-file

Depends on: walking-skeleton · Estimate: 2 · Suits: senior

Files: src/library/storage.py, src/library/library.py; tests: tests/test_data_file.py.

Interfaces: `storage.load(path) -> dict`, `storage.save(path, data) -> None`; `Book(isbn, title, copies)`, `Loan(member, isbn, checked_out, due)`; `Library(path)`, `Library.books`, `Library.loans`.

- [ ] B1, B2: write the failing missing-file and round-trip tests in tests/test_data_file.py; see them fail
- [ ] B1, B2: implement `storage.load`, `Book`, `Loan` and `Library.__init__` with the views; the tests pass
- [ ] B5, B6: write the failing invalid-JSON and no-write tests (bytes compared before and after); see them fail
- [ ] B5, B6: raise `StorageError` with the path in the message; the tests pass
- [ ] B7: write the failing test that an `OSError` on open is raised as it is, not as `StorageError`; see it fail
- [ ] B7: let the `OSError` through in `storage.load`; the test passes
- [ ] B3, B4: write the failing atomic-write tests (temp file gone, forced failure in the dump or in `os.replace` keeps old bytes and removes the temp file); see them fail
- [ ] B3, B4: implement `storage.save` as in ADR 0001; the tests pass
- [ ] run `pytest -q tests/test_data_file.py`, then the whole suite, ruff and mypy

### catalogue

Depends on: data-file · Estimate: 1 · Suits: any

Files: src/library/library.py; tests: tests/test_catalogue.py.

Interfaces: `Library.add_book(isbn: str, title: str, copies: int) -> None`; `Library.find_book(isbn: str, raise_missing: bool = True) -> Book | None`.

- [ ] B1, B5: write the failing add-and-hold tests in tests/test_catalogue.py; see them fail
- [ ] B1, B5: implement `add_book` (checks first, then append); the tests pass
- [ ] B2, B3, B4, B9: write the failing find tests (found, `raise_missing=False`, case-sensitive, unknown isbn); see them fail
- [ ] B2, B3, B4, B9: implement `find_book`; the tests pass
- [ ] B6, B7, B8: write the failing validation and duplicate tests; see them fail
- [ ] B6, B7, B8: add the validation and duplicate checks before any change; the tests pass
- [ ] B11: write the failing test that a new `Library(path)` holds the book after `add_book`; see it fail
- [ ] B11: call `storage.save` before `add_book` returns; the test passes
- [ ] B10: write the no-write test (a successful `add_book` calls the `storage.save` spy once, each failing call of B6, B7, B8 never; file bytes unchanged); it fails until B11 is in place, run it after B11 and see it pass
- [ ] run `pytest -q tests/test_catalogue.py`, then the whole suite, ruff and mypy

### lending

Depends on: catalogue, data-file · Estimate: 2 · Suits: senior

Files: src/library/lending.py, src/library/library.py; tests: tests/test_lending.py.

Interfaces: `LOAN_LIMIT = 3`, `LOAN_DAYS = 14`, `due_date(checked_out: date) -> date`; `Library.check_out(member: str, isbn: str, day: date) -> None`; `Library.available(isbn: str) -> int`; `is_overdue(due: date, day: date) -> bool`; `Library.return_book(member: str, isbn: str, day: date) -> None`.

- [ ] B8: write the failing source-scan test for one definition of each limit in `src/library/`; run it and see it fail
- [ ] B1, B2, B3, B4, B5: write the failing check-out tests (loan fields, due date 2026-03-15 and 2026-03-06, third loan accepted, same isbn twice, free copy count); see them fail
- [ ] B1, B2, B3, B4, B5, B8: add the constants and `due_date` in lending.py, `available` and `check_out` in library.py; the tests pass
- [ ] B9, B10, B11, B12: write the failing refusal tests (limit, no copy, unknown isbn, order); see them fail
- [ ] B9, B10, B11, B12: order the checks and run them before any change; the tests pass
- [ ] B6, B7, B13: write the failing return and invariant tests (day as third argument, earliest of two loans removed); see them fail
- [ ] B6, B7, B13: implement `return_book(member, isbn, day)` with the message "Book {isbn} is not on loan to member {member}"; the tests pass
- [ ] B15, B12: write the failing overdue tests (due 2026-03-15: accepted on 2026-03-15, refused on 2026-03-16; order pairs); see them fail
- [ ] B15, B12: add `is_overdue` in lending.py and the second check in `check_out`; the tests pass
- [ ] B16: write the failing test that a new `Library(path)` sees the loan after `check_out` and not after `return_book`; see it fail
- [ ] B16: call `storage.save` before `check_out` and `return_book` return; the test passes
- [ ] B14: write the no-write tests (a successful call hits the `storage.save` spy; each refused `check_out` of B9, B10, B11, B15 and the refused `return_book` of B13, the LoanNotFoundError case, never does; file bytes unchanged); they fail until B16 is in place, run them after B16 and see them pass
- [ ] run `pytest -q`, ruff and mypy
