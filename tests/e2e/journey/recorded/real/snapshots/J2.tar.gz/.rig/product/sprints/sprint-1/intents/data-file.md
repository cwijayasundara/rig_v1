---
sprint: 1
prd: [FR-1, NFR-1]
depends: [walking-skeleton]
estimate_days: 2
kind: internal
owner:
status: draft
scope: [src/library/storage.py, src/library/library.py, tests/test_data_file.py]
touches: []
---
# Data file: load, save and atomic write

## Intent

Books and loans must survive between runs in one JSON file that is never left half-written (FR-1). This intent builds `storage.load` and `storage.save`, and `Library(path)`, which loads the file when it is built. It also defines the `Book` and `Loan` records and the read-only views `Library.books` and `Library.loans`, so the later intents add rules on top. Done: AC-1.1 to AC-1.4 and NFR-1 have passing tests, and the format of ADR 0002 is in place.

`storage.save` is called by the mutating calls of the next intents: a successful `add_book`, `check_out` or `return_book` writes the data file before it returns, with no separate `save()` call (PRD Decision, decided at chart). Those behaviours live in the catalogue and lending intents.

## Non-goals

- Do not add `add_book`, `find_book`, `check_out`, `return_book` or `available`.
- Do not take a lock or handle file permissions (PRD Decision: single user, one process at a time).
- Do not add a runtime dependency; do not change the format of ADR 0002 (PRD: ask first).

## Design

| Part | Responsibility | Must not |
|---|---|---|
| `storage.load(path)` | reads the file, returns `{"books": [...], "loans": [...]}`; a missing file gives two empty lists | write or touch the file |
| `storage.save(path, data)` | writes atomically as in ADR 0001: temp file in the target's directory, `os.replace` | write the data file in place |
| `Book`, `Loan` (frozen dataclasses in `library.py`) | `Book(isbn, title, copies)`; `Loan(member, isbn, checked_out: date, due: date)` (DR-2) | hold rules |
| `Library.__init__(path)` | loads on construction; keeps books and loans in memory | write the file |
| `Library.books`, `Library.loans` | read-only tuples of `Book` and `Loan`, in file order | let a caller change the state |

## Interfaces

none (internal)

## Behaviours

- B1 (FR-1, AC-1.1): `Library(path)` where `path` does not exist holds no books and no loans, and does not create the file.
- B2 (FR-1, AC-1.2): after `storage.save` of one book (isbn "978-1", title "Dune", 2 copies) and one loan (member "m1", isbn "978-1", checked out 2026-03-01, due 2026-03-15), `Library(path)` on the same file holds the same book and the same loan, with dates as `datetime.date`.
- B3 (NFR-1): `storage.save` writes a temp file in the same directory as the data file, then `os.replace`s it onto the data file; the temp file is gone afterwards.
- B4 (FR-1, NFR-1): when the write of the temp file fails or is interrupted (error raised in the dump, or in `os.replace`), the data file keeps its previous bytes, the temp file is removed, and the error is raised: 0 half-written files.

### Failure behaviour

- B5 (FR-1, AC-1.4): `Library(path)` on a file that is not valid JSON raises `StorageError` whose message contains the file path, and the file is byte-for-byte unchanged.
- B6 (FR-1, AC-1.3): any `Library(path)` that raises an error does not write the data file or create a temp file next to it.
- B7 (FR-1, AC-1.3): `Library(path)` on a data file that exists but cannot be read (`OSError` on open) raises that `OSError` as it is, not wrapped in `StorageError`, and writes nothing (PRD Decision, decided at chart: an unreadable data file is raised as the OSError).

## Tests required

- B1, B2, B5, B6, B7: unit, `tests/test_data_file.py` (pytest `tmp_path`; B5 compares bytes before and after; B7 makes `open` raise `PermissionError` with `monkeypatch`, or uses a directory as the path).
- B3, B4: unit, `tests/test_data_file.py` (B4 forces an error with `monkeypatch` on `os.replace` and on `json.dump`).

## Open questions

none