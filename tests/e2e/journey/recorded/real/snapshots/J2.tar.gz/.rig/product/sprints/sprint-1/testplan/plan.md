# Test plan: Library Desk, sprint 1

## Strategy

All tests are pytest unit tests in `tests/` (standard library only, `tmp_path` for every file). The library has no network, UI or service, so there are no contract, integration, perf or security levels this sprint.

- Unit: each intent's behaviours (B-numbers) are proved in its own test file: `test_errors.py` (walking-skeleton), `test_data_file.py` (data-file), `test_catalogue.py` (catalogue), `test_lending.py` (lending).
- Failure cases: AC-1.3 (a raising call does not write the file) is checked by comparing the file bytes, or its absence, before and after, in data-file, catalogue and lending (TC-17, TC-30, TC-45, TC-46, each with a spy that `storage.save` is never called, since the PRD Decision now writes on every success). AC-1.4 (invalid file stays byte-for-byte unchanged) is TC-14. AC-5.3 (copy count stays between 0 and 2 in any order) is TC-37 and TC-38.
- NFR-1 is proved by forcing an error in `json.dump` and in `os.replace` and checking the old bytes and no temp file. NFR-2 is an AST scan of `src/library/` for the integer constants 3 and 14 outside lending.py (TC-39).
- Access: the PRD sets no access rule and architecture.md has no `## Access` section, and none of this sprint's intents has an `## Access` row. So there is no allowed/refused case per interface, and none is invented.

### Open questions settled

No case is blocked. The `prd.md` Decisions answer every former open question:

- OQ-1: overdue means the due date is before the check_out day; a loan due that day is not overdue (TC-47, TC-48, and the boundary pair TC-50 and TC-52).
- GQ-1: `return_book(member, isbn, day)` takes a required day (TC-36, TC-37, TC-44, TC-46, TC-54, TC-55; TC-57 and TC-58 call without the day and expect TypeError).
- GQ-2: a successful add_book, check_out or return_book writes the file before it returns (TC-51, TC-53, TC-54; AC-1.2).
- GQ-3: no scale or performance target, so no case.
- Two loans of one isbn returned once: the earliest checked-out loan is removed (TC-55).
- Unreadable data file: the OSError is raised as it is, not StorageError (TC-56).

## Environments and data

Local machine, Python 3.11+, `pytest -q`. No external services. Test data is synthetic: isbn "978-1", title "Dune", members "m1", "m2", dates such as 2026-03-01. Files are under `.rig/product/sprints/sprint-1/testplan/data/`:

- `data/valid.json`: one book (978-1, Dune, 2 copies) and one loan (m1, 2026-03-01, due 2026-03-15), in the ADR 0002 shape.
- `data/invalid.json`: truncated, not valid JSON (AC-1.4).

Tests copy a data file into `tmp_path` before use, so the originals are never changed.

## Entry and exit criteria

Entry: the sprint's intents are approved and the PRD has no open questions.

Exit: every case passes in `pytest -q`; ruff and mypy are clean; every FR, NFR, AC and DR of requirements.md has at least one case.

## Regression scope

`tests/test_smoke.py` (package imports) must stay green. Every case in this plan must still pass when the sprint merges. The failure rule of AC-1.3 must hold for every later mutating call.
