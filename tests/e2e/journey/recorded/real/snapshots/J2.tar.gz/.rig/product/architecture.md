---
sprint: 1
updated: 2026-11-01
design: docs/superpowers/specs/2026-11-01-sprint-1-design.md
---
# Architecture

## Context

Library Desk is a small Python library for a library desk. A librarian (code calling the library) adds books, looks them up, lends a free copy to a member and takes it back. Books and loans live in one JSON file on local disk. A member is an id string on a loan; there is no member registry, no command line and no UI. One process at a time, no locking.

## Technology stack

| Concern | Choice | Version | Source |
|---|---|---|---|
| Language | Python | 3.11+ | PRD Integrations and constraints; `requires-python` in pyproject.toml |
| Framework | none (standard library) | | PRD: standard library only at runtime |
| Libraries | `json`, `datetime`, `os`, `tempfile` | standard library | PRD; ADR 0001 |
| Data store | one JSON file | | PRD Decision 2026-10-31; ADR 0002 |
| Test | pytest | as installed (9.x) | PRD; `[tool.pytest.ini_options]` |
| Lint and types | ruff, mypy | as installed | repo commands (CLAUDE.md) |
| Packaging | `src` layout, `pythonpath = ["src"]` | | pyproject.toml |
| Hosting | none: a library imported by the caller | | PRD |

## Architecture diagram

```mermaid
flowchart LR
    Caller[Caller: librarian code] --> Library[library.py: Library]
    Library --> Lending[lending.py: LOAN_LIMIT, LOAN_DAYS]
    Library --> Storage[storage.py: load, save]
    Library --> Errors[errors.py: 8 exceptions]
    Storage --> Errors
    Storage --> File[(data file: JSON)]
```

```text
 +-----------------+      +---------------------------+
 | Caller          | ---> | library.py: Library       |
 +-----------------+      +---------------------------+
                            |         |            |
                            v         v            v
          +----------------------+  +-----------------+  +------------------+
          | lending.py           |  | storage.py      |  | errors.py        |
          | LOAN_LIMIT, LOAN_DAYS|  | load, save      |->| 8 exceptions     |
          +----------------------+  +-----------------+  +------------------+
                                            |
                                            v
                                    +----------------+
                                    | data file JSON |
                                    +----------------+
```

## Code structure

```text
src/library/
  __init__.py   # re-exports Library and the eight errors (sprint 1)
  errors.py     # ValidationError, DuplicateIsbnError, BookNotFoundError, LoanLimitError,
                # NoCopyAvailableError, OverdueLoanError, LoanNotFoundError, StorageError (sprint 1)
  storage.py    # load (missing file = empty) and atomic save (sprint 1)
  lending.py    # LOAN_LIMIT = 3, LOAN_DAYS = 14, due_date, is_overdue (sprint 1)
  library.py    # Book, Loan, Library: add_book, find_book, check_out, return_book, available (sprint 1)
tests/
  test_smoke.py       # imports the package (exists)
  test_errors.py      # error classes (sprint 1)
  test_data_file.py   # load, save, atomic write (sprint 1)
  test_catalogue.py   # add_book, find_book (sprint 1)
  test_lending.py     # check_out, return_book, available, single definition of the limits (sprint 1)
```

## Containers and modules

| Module | Responsibility | Must not |
|---|---|---|
| `errors.py` | the eight exception classes | import another module of the package |
| `storage.py` | read the JSON file, write it atomically | know the lending rules; import `library` or `lending` |
| `lending.py` | the loan limit, the loan period, the due date | import `library` or `storage`; be repeated elsewhere (NFR-2) |
| `library.py` | `Library`: state in memory, every rule check, calls `storage.save` before a successful `add_book`, `check_out` or `return_book` returns | write the file except through `storage.save`; change state before all checks pass |

Dependencies point one way: `library` -> `lending`, `storage`, `errors`; `storage` -> `errors`.

## Key flows

Check out a book (S1, S2):

```mermaid
sequenceDiagram
    participant C as Caller
    participant L as library.py Library
    participant G as lending.py
    participant S as storage.py
    C->>L: check_out("m1", "978-1", day)
    L->>L: find_book: unknown isbn?
    L->>L: overdue? (due date before day)
    L->>G: LOAN_LIMIT, due_date(day)
    L->>L: loan limit? free copy?
    L->>L: record Loan
    L->>S: save(path, data)
    S-->>L: file replaced atomically
    L-->>C: done, or an error and nothing changed
```

```text
1. Caller  -> Library : check_out(member, isbn, day)
2. Library -> Library : unknown isbn?  -> BookNotFoundError
3. Library -> Library : overdue?       -> OverdueLoanError   (due date before day)
4. Library -> Library : 3 loans held?  -> LoanLimitError     (LOAN_LIMIT from lending.py)
5. Library -> Library : no free copy?  -> NoCopyAvailableError
6. Library -> Lending : due_date(day) = day + LOAN_DAYS
7. Library -> Library : record the Loan
8. Library -> Storage : save(path, data)9. Storage -> File    : temp file, then os.replace
```

Load the library (AC-1.1, AC-1.4):

```mermaid
sequenceDiagram
    participant C as Caller
    participant L as library.py Library
    participant S as storage.py
    C->>L: Library(path)
    L->>S: load(path)
    S-->>L: books and loans, or empty if the file is missing
    S-->>L: StorageError naming the file if not valid
    L-->>C: Library, or the error
```

```text
1. Caller  -> Library : Library(path)
2. Library -> Storage : load(path)
3. Storage -> File    : read (a missing file gives no books and no loans)
4. Storage -> Library : the data, or StorageError naming the file (file unchanged)
5. Library -> Caller  : the Library, or the error
```

## Data

One JSON file with `books` and `loans` arrays; dates are ISO strings in the file and `datetime.date` in memory (ADR 0002). The free-copy count is derived (`copies` minus loans of the isbn), never stored. Invariants: isbn unique and exact (DR-1), copies an integer of 1 or more (DR-3), at most 3 loans per member (DR-4), due date 14 days after check-out (DR-5).

## Integrations

None. The only external thing is the data file, fixed by ADR 0002. No HTTP, message or downstream interface, so no contract files.

## Quality tactics

| NFR | Target | Tactic | Where | Verified by |
|---|---|---|---|---|
| NFR-1 | 0 half-written files after a failed or interrupted write | write a temp file in the data file's directory, then `os.replace` (ADR 0001) | `storage.save` | unit test in tests/test_data_file.py (forced failure keeps old bytes) |
| NFR-2 | 1 definition each, 0 repeated literals | `LOAN_LIMIT` and `LOAN_DAYS` defined once and imported | `lending.py` | review, and a source-scan test in tests/test_lending.py |

## Deployment

None: a library imported by the caller's Python 3.11+ process. The data file path is given to `Library(path)`.

## Sprint history

| Sprint | Adds | Intents | ADRs |
|---|---|---|---|
| 1 | package modules and errors, load and atomic save, add and find a book, check out and return | walking-skeleton, data-file, catalogue, lending | 0001, 0002 |

## Decisions

| ADR | Decision | Status | Sprint |
|---|---|---|---|
| 0001 | atomic write by temp file and `os.replace` | accepted | 1 |
| 0002 | data file format: `books` and `loans` arrays, ISO dates | accepted | 1 |

## Concerns

none

## Open questions

none
