---
sprint: 1
status: accepted
date: 2026-11-01
decides: [AC-1.2, DR-1, DR-2, DR-3]
---
# ADR 0002: Data file format

## Context

AC-1.2 needs the same book and loan back after a save and a load; DR-2 says what a loan records. The PRD says "Ask first: changing the data file format", so the first format is fixed here and any later change needs a new ADR.

## Decision

One JSON object with two arrays, written with `json.dump` (UTF-8):

```json
{
  "books": [{"isbn": "978-1", "title": "Dune", "copies": 2}],
  "loans": [{"member": "m1", "isbn": "978-1", "checked_out": "2026-03-01", "due": "2026-03-15"}]
}
```

- Dates are ISO 8601 `YYYY-MM-DD` strings (`date.isoformat()` / `date.fromisoformat()`); in memory they are `datetime.date`.
- The number of free copies is not stored: it is `copies` minus the number of loans of that isbn, so it can never drift from the loans (AC-5.3).
- A missing file loads as `{"books": [], "loans": []}` (AC-1.1).

## Consequences

- Plain JSON can be read and fixed by hand.
- Loans are an ordered array, so the order of check-outs is kept.
