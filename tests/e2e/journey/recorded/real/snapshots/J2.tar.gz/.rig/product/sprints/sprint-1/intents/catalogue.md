---
sprint: 1
prd: [FR-2, FR-3]
depends: [data-file]
estimate_days: 1
kind: internal
owner:
status: draft
scope: [src/library/library.py, tests/test_catalogue.py]
touches: []
---
# Catalogue: add a book and find a book

## Intent

The librarian adds a book with an isbn, a title and a number of copies (FR-2) and looks a book up by isbn (FR-3). This intent adds `Library.add_book` and `Library.find_book` on top of the loaded state of data-file. Done: AC-2.1 to AC-2.4 and AC-3.1 to AC-3.4 have passing tests, and a failed call changes nothing in memory and writes nothing.

A successful `add_book` writes the data file before it returns, with no separate `save()` call; a call that raises writes nothing (PRD Decision, decided at chart; B11 and B10).

## Non-goals

- Do not edit or remove a book (PRD non-goal).
- Do not add `check_out`, `return_book` or `available`.
- Do not normalise an isbn (no trimming, no case folding): matching is exact (DR-1).
- Do not write the data file from a call that raises.

## Design

| Part | Responsibility | Must not |
|---|---|---|
| `Library.add_book(isbn, title, copies)` | checks every rule first (valid fields, then not a duplicate), then adds a `Book` | change state before all checks pass |
| `Library.find_book(isbn, raise_missing=True)` | returns the `Book` for the exact isbn; with `raise_missing=False` returns `None` for an unknown isbn | match case-insensitively or by prefix |

## Interfaces

none (internal)

## Behaviours

- B1 (FR-2, AC-2.1): on an empty library, `add_book("978-1", "Dune", 2)` leaves the library holding that book with 2 copies (`Library.books` has `Book("978-1", "Dune", 2)`).
- B2 (FR-3, AC-3.1): given a book with isbn "978-1", `find_book("978-1")` returns the book with its title and copies.
- B3 (FR-3, AC-3.3): given a book with isbn "978-1", `find_book("999", raise_missing=False)` returns `None` instead of raising.
- B4 (FR-3, AC-3.4, DR-1): given a book with isbn "ABC-1", `find_book("abc-1")` raises `BookNotFoundError`: isbn matching is exact and case-sensitive.
- B5 (FR-2, DR-1, DR-3): an isbn is a non-empty string, unique in the catalogue, and `copies` is an integer of 1 or more; `add_book("978-1", "Dune", 1)` is accepted.
- B11 (FR-1, AC-1.2, AC-1.3): a successful `add_book` writes the data file before it returns (through `storage.save`; there is no `save()` call): a new `Library(path)` on the same file holds the added book. A call that raises writes nothing (B10).

### Failure behaviour

- B6 (FR-2, AC-2.2, DR-1): `add_book` with an empty isbn, an isbn that is not a string, or an empty title raises `ValidationError` and leaves the library unchanged.
- B7 (FR-2, AC-2.3, DR-3): `add_book` with copies below 1 (0 and -1 tested) or not an integer ("2" and 1.5 tested) raises `ValidationError` and leaves the library unchanged.
- B8 (FR-2, AC-2.4, DR-1): `add_book` with an isbn already in the catalogue raises `DuplicateIsbnError` and leaves the library unchanged: the first book keeps its title and copies.
- B9 (FR-3, AC-3.2): `find_book` with an isbn that is not in the catalogue raises `BookNotFoundError`.
- B10 (FR-1, AC-1.3): a call of B6, B7 or B8 does not write the data file: the file's bytes (or its absence) are the same after the call.

## Tests required

- B1 to B9, B11: unit, `tests/test_catalogue.py` (B11 reloads the file with a new `Library(path)`).
- B10: unit, `tests/test_catalogue.py` (file bytes compared before and after, using `tmp_path`; also a spy on `storage.save` that is never called).

## Open questions

none
