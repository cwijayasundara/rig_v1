---
sprint: 1
status: accepted
date: 2026-11-01
decides: [NFR-1, AC-1.3, AC-1.4]
---
# ADR 0001: Atomic write by temp file and os.replace

## Context

NFR-1 asks for writes that leave 0 half-written files after a failed or interrupted write (PRD: "write a temp file, then rename"). AC-1.4 asks that a data file that is not valid JSON stays byte-for-byte unchanged. The PRD Decisions fix one process at a time, no locking and no file permission handling, so the write only has to be safe against a failure or an interruption, not against a second writer.

## Decision

`storage.save(path, data)` writes in this order:

1. Create a temp file in the same directory as the data file with `tempfile.mkstemp(dir=<that directory>)`. The same directory keeps the rename on one filesystem.
2. Write the JSON text to the temp file, `flush()` and `os.fsync()` it, close it.
3. `os.replace(temp, path)`. This is the only step that changes the data file, and it is atomic.
4. If any step raises, including `os.replace` itself, remove the temp file and re-raise; the data file keeps its previous content.

`storage.load(path)` only reads. It never writes, so an invalid file (AC-1.4) is never touched.

## Consequences

- A reader sees the old file or the new file, never a mix.
- A crash between step 1 and step 3 can leave a stray temp file next to the data file but never a half-written data file; the temp file name starts with the data file name so it is easy to spot.
- No dependency is added: `json`, `os` and `tempfile` are standard library.
- No lock is taken (PRD Decision: single user, one process at a time).

## Alternatives

- Write the data file in place: rejected, a failure mid-write leaves a half-written file (NFR-1).
- Write to a fixed name such as `data.json.tmp`: rejected, a leftover from an earlier crash would be reused silently.
