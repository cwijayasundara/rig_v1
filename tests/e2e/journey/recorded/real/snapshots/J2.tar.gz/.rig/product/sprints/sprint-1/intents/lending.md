---
sprint: 1
prd: [FR-4, FR-5, NFR-2]
depends: [catalogue, data-file]
estimate_days: 2
kind: internal
owner:
status: draft
scope: [src/library/lending.py, src/library/library.py, tests/test_lending.py]
touches: []
---
# Lending: check out and return a book

## Intent

The librarian lends a free copy of a book to a member under the desk's rules (FR-4) and takes it back so the copy becomes free (FR-5). This intent adds `LOAN_LIMIT = 3` and `LOAN_DAYS = 14` in `lending.py` (the only definitions, NFR-2), `Library.check_out`, `Library.return_book` and `Library.available`. `check_out` calls `find_book` for the isbn check. Done: AC-4.1 to AC-4.5 (overdue, B15) and AC-5.1 to AC-5.3 have passing tests, the check order of the PRD Decision holds, and a failed call changes nothing and writes nothing.

Settled by the PRD Decisions: a loan is overdue when its due date is before the `check_out` day (checked at `check_out` only: no background job, no stored overdue flag); `return_book` takes the day as a required third argument; a successful `check_out` or `return_book` writes the data file before it returns, with no `save()` call (decided at chart).

## Non-goals

- Do not add fines, reservations, renewals or reports (PRD non-goals), and no member registry: a member is an id string on a loan.
- Do not default the day to today: the day is a required argument of `check_out` and `return_book` (PRD Decision).
- Do not add a background job or a stored overdue flag: overdue is worked out at `check_out` only.
- Do not write the number 3 or 14 for the limit or the period anywhere but `lending.py` (NFR-2).
- Do not store the free-copy count: it is `copies` minus the loans of that isbn.

## Design

| Part | Responsibility | Must not |
|---|---|---|
| `lending.LOAN_LIMIT`, `lending.LOAN_DAYS` | `3` (DR-4) and `14` (DR-5), the only definitions | be repeated as literals elsewhere in `src/library/` |
| `lending.due_date(checked_out)` | `checked_out + timedelta(days=LOAN_DAYS)` | import `library` or `storage` |
| `lending.is_overdue(due, day)` | `due < day`: a loan due on `day` is not overdue | store a flag or run in the background |
| `Library.check_out(member, isbn, day)` | runs the checks in the PRD Decision order, then records a `Loan` and writes the file | change state or write the file before all checks pass |
| `Library.return_book(member, isbn, day)` | removes the earliest checked-out loan of the isbn held by the member, then writes the file | change state when the member does not hold the book |
| `Library.available(isbn)` | `copies` minus the number of loans of that isbn | return a stored count |

## Interfaces

none (internal)

## Behaviours

- B1 (FR-4, AC-4.1, DR-2): given a book with a free copy, `check_out("m1", "978-1", date(2026, 3, 1))` records a loan with member "m1", isbn "978-1", checked-out day 2026-03-01 and due date 2026-03-15, and the book has one free copy fewer (2 copies: `available("978-1")` goes from 2 to 1).
- B2 (FR-4, AC-4.1, DR-5): the due date is 14 days after the day it is checked out: a check-out on 2026-02-20 is due 2026-03-06.
- B3 (FR-4, DR-4): a member may hold at most 3 books on loan at the same time: the third `check_out` for the member succeeds, the fourth is refused (B9).
- B4 (FR-4, DR-4): a member may hold more than one loan of the same isbn (PRD Decision); each counts toward the limit of 3.
- B5 (FR-4, DR-7): a book can only be lent while at least one of its copies is free: with 2 copies and 1 loan the next `check_out` succeeds, with 2 loans it is refused (B10).
- B6 (FR-5, AC-5.1): given m1 holds a loan of "978-1", `return_book("m1", "978-1", day)` (the day is a required third argument; the two-argument call in AC-5.1 is shorthand for it) removes the loan and the book has one free copy more. When m1 holds two loans of "978-1" and returns it once, the loan checked out earliest is removed (PRD Decision, decided at chart).
- B7 (FR-5, AC-5.3, DR-7): given a book with 2 copies, any order of `check_out` and `return_book` calls (accepted or refused) keeps `available("978-1")` between 0 and 2.
- B8 (NFR-2, DR-4, DR-5): `LOAN_LIMIT = 3` and `LOAN_DAYS = 14` are each defined once, in `lending.py`; no other file under `src/library/` defines them or repeats their value as a literal for the limit or the period (1 definition each, 0 repeated literals).

### Failure behaviour

- B9 (FR-4, AC-4.2, DR-4): `check_out` for a member who already holds 3 loans raises `LoanLimitError` and leaves the library unchanged.
- B10 (FR-4, AC-4.3, DR-7): `check_out` for a book with no free copy raises `NoCopyAvailableError` and leaves the library unchanged.
- B11 (FR-4, AC-4.4): `check_out` for an isbn not in the catalogue raises `BookNotFoundError` and leaves the library unchanged.
- B12 (FR-4, AC-4.2, AC-4.3, AC-4.4, AC-4.5): when a `check_out` breaks more than one rule, the first in this order is raised: unknown isbn (`BookNotFoundError`), overdue loan (`OverdueLoanError`: a loan whose due date is before the `check_out` day), loan limit (`LoanLimitError`), no free copy (`NoCopyAvailableError`). Tested for each neighbouring pair: unknown isbn before overdue, overdue before the loan limit, the loan limit before no free copy.
- B13 (FR-5, AC-5.2): `return_book("m1", "978-1", day)` for a member who does not hold that book raises `LoanNotFoundError` with the message "Book 978-1 is not on loan to member m1" (isbn and member filled in) and leaves the library unchanged.
- B14 (FR-1, AC-1.3): a `check_out` or `return_book` that raises (B9 to B13, B15) does not write the data file: its bytes (or its absence) are the same after the call.
- B15 (FR-4, DR-6, AC-4.5): a member with an overdue loan cannot borrow another book: `check_out` raises `OverdueLoanError` and leaves the library unchanged. A loan is overdue when its due date is before the day of the `check_out` call; a loan due on that day is not overdue (a loan due 2026-03-15: a `check_out` on 2026-03-15 is accepted, one on 2026-03-16 is refused). Overdue is checked at `check_out` only: no background job and no stored overdue flag.
- B16 (FR-1, AC-1.2, AC-1.3): a successful `check_out` or `return_book` writes the data file before it returns (through `storage.save`; there is no `save()` call): a new `Library(path)` on the same file holds the loan after a `check_out` and no longer holds it after a `return_book`. A call that raises writes nothing (B14).

## Tests required

- B1 to B7, B9 to B13, B15, B16: unit, `tests/test_lending.py` (B7 as a property-style test over many call sequences on a 2-copy book; B15 on both sides of the due date; B16 reloads the file with a new `Library(path)`).
- B8: unit, `tests/test_lending.py` (reads the files of `src/library/` and counts definitions and literals).
- B14: unit, `tests/test_lending.py` (file bytes compared before and after, using `tmp_path`; also a spy on `storage.save` that is never called).

## Open questions

none
