# library-desk

sdlc routes all work in this repo: start with /rig-start; use superpowers skills only when an sdlc skill names one.

## What this is

A small Python (>=3.11) library for a library desk: catalogue and loans in one JSON file, with lending rules checked on borrow and return. Sprint PRDs are in `docs/prd/`. Only the package skeleton exists so far.

## Map

- `src/library/` — the package (currently just `__init__.py`)
- `tests/` — pytest tests (`test_smoke.py` imports the package)
- `docs/prd/` — PRD template and sprint PRDs
- `.rig/` — vendored sdlc harness and sensors; do not hand-edit
- `.claude/` — rig skills, agents, hooks and settings

## Commands

- Test: `pytest -q`; fast targeted: `pytest -q tests/test_smoke.py -x`
- Lint: `ruff check src tests`
- Types: `mypy --exclude '^\.(rig|claude)/' .`
- Sensors: `node .rig/bin/sdlc.ts baseline`

## Conventions

- `src` layout; pytest uses `pythonpath = ["src"]`.
- Tests only in `tests/`; fix code, never weaken tests.
- Secrets come from the environment, never the repo.

## Gotchas

- Git hooks run rig checks on commit and push (`core.hooksPath = .rig/githooks`).
- Edits to `.rig/sensors.json` and `.claude/settings.json` need a person's confirmation.
- The duplication sensor uses `npx` (network); sast and audit need semgrep and pip-audit.

## Review

- Flag any API, schema or event change that the change's plan.md `## Contracts` does not announce.
- Flag anything the brief's non-goals exclude.

# Compact instructions

Keep the active sdlc change, failing tests and file paths; drop exploration output.

<!-- rig:guides start hash=0a7051b2e4291c9f -->
- Ruff must pass on every file you touch; fix the code rather than the rule. [sensor:lint]
- The project must type-check with mypy before the turn ends. [sensor:types]
- Run pytest before claiming done; fix the code, never the tests. [sensor:unit]
- Respect the approved layers in architecture.md; do not import across a forbidden boundary. [sensor:layers]
- Reuse existing code instead of copying it; the duplicated share may not grow past its baseline. [sensor:duplication]
- Semgrep scans the source files this change touches for security bugs (injection, unsafe input, secrets, weak crypto); fix the code rather than silencing the rule. [sensor:sast]
- Do not add dependencies with known vulnerabilities. [sensor:audit]
- Tests must assert behaviour so that changing the code makes them fail. [sensor:mutation]
- Never write credentials into the repo; read them from the environment. [sensor:secrets]
- Fix the code, never the test: do not skip, delete or weaken tests or lower coverage thresholds. [sensor:test-tamper]
- Do not silence a lint or type error without a reason on the same line. [sensor:suppression]
- Do not weaken .rig/sensors.json, .rig/rules.json or frozen contract files; ask a person to waive instead. [sensor:harness-tamper]
- Keep files, diffs and lines under the size limits; the size finding names each file and line over the limit, so fix those rather than searching for them. [sensor:size]
- Respect the declared layer rules; do not import across a forbidden boundary. [sensor:layering]
- Follow the project rules in .rig/rules.json. [sensor:rules]
- A new test must fail before the change and pass after it. [sensor:red-proof]
- Every behaviour in the change spec.md needs a test that names its B-number; brief behaviours with no test yet only warn. [sensor:traceability]
- Build on the build model; leave diff review to the /rig-pr reviewer; the evaluator agent reviews charts, plans and test plans. [sensor:model-role]
<!-- rig:guides end -->
